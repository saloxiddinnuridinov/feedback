<?php $__env->startSection('title', '"Ipak yoʻli" turizm va madiny meros xalqaro universiteti'); ?>

<?php $__env->startSection('style'); ?>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .pagination {
            display: flex;
            justify-content: center;
            padding: 20px 0;
        }

        .pagination a {
            color: black;
            float: left;
            padding: 8px 16px;
            text-decoration: none;
            transition: background-color 0.3s;
            margin: 0 4px;
            border: 1px solid #ddd;
        }

        .pagination a.active {
            background-color: #4CAF50;
            color: white;
            border: 1px solid #4CAF50;
        }

        .pagination a:hover:not(.active) {
            background-color: #ddd;
        }

        /* Umumiy moslashuv */
        body {
            font-family: Arial, sans-serif;
        }

        /* Mobil uchun media query */
        @media (max-width: 768px) {
            /* Sahifadagi kartalarni mobil uchun moslashtirish */
            .card {
                margin: 10px;
            }

            /* Jadval ko'rinishini yaxshilash */
            .table-responsive {
                overflow-x: auto;
            }

            /* Jadval hujayralarini vertikal yo'nalishda joylashtirish */
            .table tbody tr {
                display: block;
                margin-bottom: 15px;
                border-bottom: 1px solid #ddd;
            }

            .table tbody tr td {
                display: block;
                text-align: left;
            }

            .table thead {
                display: none; /* Jadval boshini yashirish */
            }

            /* Modal o‘lchamlarini mobil uchun moslashtirish */
            .modal-dialog {
                max-width: 95%;
                margin: 20px auto;
            }

            /* Formalarni ustun joylashuvdan qatordan joylashuvga o‘tkazish */
            .form-group {
                width: 100%;
                margin-bottom: 15px;
            }

            /* Kichikroq ekranda tugmalarni moslashtirish */
            .btn {
                font-size: 14px;
                padding: 10px;
                width: 100%;
                margin-bottom: 10px;
            }

            /* Filtrlash formalarini ustun joylashuvdan qatordan joylashuvga o‘tkazish */
            .row {
                flex-direction: column;
            }

            .pagination {
                flex-direction: column;
            }

            /* Yozuv uzunligiga moslashtirish */
            td ul li {
                white-space: normal;
                overflow: hidden;
                text-overflow: ellipsis;
            }
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>




    <h1>Foydalanuvchi xabarlari</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <div class="py-3">
        <div class="justify-content-between row mx-2">
            <form method="GET" action="<?php echo e(route('admin.messages.index')); ?>">
                <div class="form-group">
                    <label for="type">Xabar turini tanlang:</label>
                    <select name="type" id="type" class="form-control">
                        <option value="">Barchasi</option>
                        <option value="Taklif" <?php echo e(request('type') == 'Taklif' ? 'selected' : ''); ?>>Taklif</option>
                        <option value="Shikoyat" <?php echo e(request('type') == 'Shikoyat' ? 'selected' : ''); ?>>Shikoyat</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-success font-weight-bold">Filtrlash</button>
            </form>
        </div>
    </div>

    <div class="py-3">
        <div class="justify-content-between row mx-2">
            <form method="GET" action="<?php echo e(route('admin.messages.index')); ?>">
                <div class="form-group">
                    <label for="date">Sanani tanlang:</label>
                    <input type="date" name="date" id="date" class="form-control" value="<?php echo e(request('date')); ?>">
                </div>
                <button type="submit" class="btn btn-success font-weight-bold">Filtrlash</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session()->has('error') || session()->has('success')): ?>
        <div class="alert <?php echo e(session()->has('error') ? 'alert-danger' : 'alert-success'); ?>">
            <?php echo e(session('error') ?? session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="container">






        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Foydalanuvchi</th>
                                    <th>Telefon</th>
                                    <th>Username</th>
                                    <th>Xabarlar</th>

                                    <th>Amallar</th>
                                    <th>Javoblar</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $telegram_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><?php echo e($user->name . ' ' . $user->surname); ?></td>
                                        <td><?php echo e($user->phone); ?></td>
                                        <td><?php echo e($user->username); ?></td>
                                        <td>
                                            <ul>



                                                <?php $__currentLoopData = $user->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($message->message); ?>

                                                        (<?php echo e($message->created_at->format('Y-m-d H:i')); ?>)
                                                    </li>
                                                    <?php break; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </td>







                                        <td>
                                            <?php if($user->messages && $user->messages->isNotEmpty()): ?>
                                                <button class="btn btn-primary" data-toggle="modal"
                                                        data-target="#replyModal<?php echo e($user->messages->last()->id); ?>">
                                                    Javob yozish
                                                </button>

                                                <div class="modal fade" id="replyModal<?php echo e($user->messages->last()->id); ?>" tabindex="-1"
                                                     role="dialog"
                                                     aria-labelledby="replyModalLabel<?php echo e($user->messages->last()->id); ?>"
                                                     aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <form
                                                                action="<?php echo e(route('admin.messages.reply', $user->messages->last()->id)); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="selected_message"
                                                                       id="selected_message<?php echo e($user->messages->last()->id); ?>">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title"
                                                                        id="replyModalLabel<?php echo e($user->messages->last()->id); ?>">Javob
                                                                        yozish</h5>
                                                                    <button type="button" class="close" data-dismiss="modal"
                                                                            aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="form-group">
                                                                        <label for="selected_message">Javob berilayotgan
                                                                            xabarni
                                                                            tanlang:</label>
                                                                        <select name="selected_message"
                                                                                id="selected_message<?php echo e($user->messages->last()->id); ?>"
                                                                                class="form-control"
                                                                                onchange="updateMessageId(<?php echo e($user->messages->last()->id); ?>)"
                                                                                required>
                                                                            <?php $__currentLoopData = $user->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option value="<?php echo e($message->id); ?>">
                                                                                    <?php echo e($message->message); ?>

                                                                                    (<?php echo e($message->created_at->format('Y-m-d H:i')); ?>

                                                                                    )
                                                                                </option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="reply">Javob</label>
                                                                        <textarea name="reply" class="form-control" rows="4"
                                                                                  required></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                            data-dismiss="modal">Bekor
                                                                        qilish
                                                                    </button>
                                                                    <button type="submit" class="btn btn-primary">Yuborish
                                                                    </button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>





                                            <!-- Javob yozish modal -->

                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('get.Person', [$user->id])); ?>"
                                               class="btn btn-primary">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="pagination">
                            <?php echo e($telegram_users->links('admin.pagination')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startSection('script'); ?>
        <script>
            function updateMessageId(modalId) {
                var selectedMessageId = document.getElementById('selected_message' + modalId).value;
                document.querySelector('form[action*="<?php echo e(route('admin.messages.reply', '')); ?>"] input[name="selected_message"]').value = selectedMessageId;
            }
        </script>
    <?php $__env->stopSection(); ?>

    <!-- jQuery (Bootstrap JS uchun zarur) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Qo'shimcha skriptlarni qo'shing -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.simple.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\feedback.loc\resources\views/admin/post/index.blade.php ENDPATH**/ ?>