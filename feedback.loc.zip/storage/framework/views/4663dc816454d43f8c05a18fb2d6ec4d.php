<script src="<?php echo e(asset('vendor_admin/js/jquery-3.5.1.min.js')); ?>"></script>
<!-- Bootstrap js-->
<script src="<?php echo e(asset('vendor_admin/js/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
<!-- feather icon js-->
<script src="<?php echo e(asset('vendor_admin/js/icons/feather-icon/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/icons/feather-icon/feather-icon.js')); ?>"></script>
<!-- scrollbar js-->
<script src="<?php echo e(asset('vendor_admin/js/scrollbar/simplebar.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/scrollbar/custom.js')); ?>"></script>
<!-- Sidebar jquery-->
<script src="<?php echo e(asset('vendor_admin/js/config.js')); ?>"></script>
<!-- Plugins JS start-->
<script src="<?php echo e(asset('vendor_admin/js/sidebar-menu.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/chart/knob/knob.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/chart/knob/knob-chart.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/chart/apex-chart/stock-prices.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/notify/bootstrap-notify.min.js')); ?>"></script>

<script src="<?php echo e(asset('vendor_admin/js/notify/index.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/datepicker/date-picker/datepicker.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/datepicker/date-picker/datepicker.en.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/datepicker/date-picker/datepicker.custom.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/photoswipe/photoswipe.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/photoswipe/photoswipe-ui-default.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/photoswipe/photoswipe.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/typeahead/handlebars.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/typeahead/typeahead.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/typeahead/typeahead.custom.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/typeahead-search/handlebars.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/typeahead-search/typeahead-custom.js')); ?>"></script>
<script src="<?php echo e(asset('vendor_admin/js/height-equal.js')); ?>"></script>
<!-- Plugins JS Ends-->
<!-- Theme js-->
<script src="<?php echo e(asset('vendor_admin/js/script.js')); ?>"></script>
<!-- login js-->
<?php /**PATH C:\OpenServer\domains\feedback.loc\resources\views/admin/layouts/simple/script.blade.php ENDPATH**/ ?>