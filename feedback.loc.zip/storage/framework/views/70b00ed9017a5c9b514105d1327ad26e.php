<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .response-wrapper {
            margin-bottom: 25px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 15px;
        }

        .response-header {
            font-weight: bold;
            font-size: 16px;
        }

        .response-body {
            margin-top: 10px;
            font-size: 14px;
        }

        .response-date {
            margin-top: 5px;
            font-size: 12px;
            color: #888;
        }

        .message-details {
            margin-bottom: 20px;
        }

        .message-details label {
            font-weight: bold;
        }

        .message-details p {
            margin-bottom: 0;
        }

        .container-fluid {
            max-width: 100%;
        }
    </style>
    <div class="container-fluid">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header pb-0">
                    <h5>Murojaat va javoblar</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12 message-details">










                            <div class="row">
                                <!-- User Field -->
                                <div class="col-sm-2">
                                    <label for="user">Foydalanuvchi:</label>
                                </div>
                                <div class="col-sm-10">
                                    <p><?php echo e($message->name . ' ' .  $message->surname); ?></p>
                                </div>
                                <div class="col-sm-2">
                                    <label for="user">Telegram:</label>
                                </div>
                                <div class="col-sm-10">
                                    <p><?php echo e($message->username . ' ' .  $message->phone); ?></p>
                                </div>
                            </div>
                        </div>

                        <!-- Responses Field -->
                        <?php $__currentLoopData = $message->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-12">
                                <h5>Savol: </h5>
                                <div class="response-wrapper">
                                    <div class="response-body">
                                        <?php echo nl2br(e($message->message)); ?>

                                    </div>
                                    <div class="response-date">
                                        Savol berilgan sana: <?php echo e($message->created_at->format('Y-m-d H:i')); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <h5>Javoblar:</h5>
                                <?php $__empty_1 = true; $__currentLoopData = $message->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="response-wrapper">
                                        <div class="response-header">
                                            Javob beruvchi: <?php echo e($answer->user->name . ' ' . $answer->user->surname); ?>

                                        </div>
                                        <div class="response-body">
                                            <?php echo nl2br(e($answer->answer)); ?>

                                        </div>
                                        <div class="response-date">
                                            Javob berilgan sana: <?php echo e($answer->created_at->format('Y-m-d H:i')); ?>

                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p>Bu murojaatga hali javob berilmagan.</p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <div class="card-footer">
                    <a class="btn btn-primary" href="<?php echo e(route('admin.messages.index')); ?>">Orqaga</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.simple.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\feedback.loc\resources\views/admin/post/show.blade.php ENDPATH**/ ?>