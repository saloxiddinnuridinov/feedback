<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control', 'required']); ?>

</div>

<!-- Surname Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('surname', 'Surname:'); ?>

    <?php echo Form::text('surname', null, ['class' => 'form-control', 'required']); ?>

</div>

<!-- Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::text('email', null, ['class' => 'form-control', 'required']); ?>

</div>

<!-- Password Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('password', 'Password:'); ?>

    <?php echo Form::text('password', null, ['class' => 'form-control', 'required']); ?>

</div>

<!-- Image Field -->
<div class="form-group col-sm-6">
    <label for="image">Image:</label>
    <input type="file" class="form-control" id="image" name="image">
</div>
<div class="clearfix"></div>

<!-- Role Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('role', 'Role:'); ?>

    <?php echo Form::select('role', ['admin' => 'admin', 'user' => 'user'], null, ['class' => 'form-control custom-select']); ?>

</div>

<!-- Role Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('specialist', 'Specialist:'); ?>

    <?php echo Form::select('specialist', ['All' => 'All', 'Sirtqi' => 'Sirtqi', 'Masofaviy' => 'Masofaviy', 'Kunduzgi' => 'Kunduzgi'], null, ['class' => 'form-control custom-select']); ?>

</div>

<!-- Is Active Field -->
<div class="form-group col-sm-6">
    <div class="form-check">
        <?php echo Form::hidden('is_active', 0, ['class' => 'form-check-input']); ?>

        <?php echo Form::checkbox('is_active', 1, null, ['class' => 'form-check-input']); ?>

        <?php echo Form::label('is_active', 'Is Active', ['class' => 'form-check-label']); ?>

    </div>
</div>
<?php /**PATH C:\OpenServer\domains\feedback.loc\resources\views/admin/user/fields.blade.php ENDPATH**/ ?>