<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor_admin/css/vendors/font-awesome.css')); ?>">
<!-- ico-font-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor_admin/css/vendors/icofont.css')); ?>">
<!-- Themify icon-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor_admin/css/vendors/themify.css')); ?>">
<!-- Flag icon-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor_admin/css/vendors/flag-icon.css')); ?>">
<!-- Feather icon-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor_admin/css/vendors/feather-icon.css')); ?>">
<!-- Plugins css start-->
<?php echo $__env->yieldContent('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor_admin/css/vendors/scrollbar.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor_admin/css/vendors/animate.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor_admin/css/vendors/date-picker.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor_admin/css/vendors/photoswipe.css')); ?>">
<!-- Plugins css Ends-->
<!-- Bootstrap css-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor_admin/css/vendors/bootstrap.css')); ?>">
<!-- App css-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor_admin/css/style.css')); ?>">
<link id="color" rel="stylesheet" href="<?php echo e(asset('vendor_admin/css/color-1.css')); ?>" media="screen">
<!-- Responsive css-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor_admin/css/responsive.css')); ?>">
<?php /**PATH C:\OpenServer\domains\feedback.loc\resources\views/admin/layouts/simple/css.blade.php ENDPATH**/ ?>