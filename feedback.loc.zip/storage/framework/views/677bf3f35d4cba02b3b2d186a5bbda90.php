<?php $__env->startSection('title', 'Add User'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 col-xl-12">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-header pb-0">
                                <h5>Add Post</h5>
                            </div>
                            <!-- Form with multipart/form-data encoding -->
                            <?php echo Form::open(['route' => 'users.store', 'enctype' => 'multipart/form-data']); ?>

                            <div class="card-body">

                                <div class="row">
                                    <?php echo $__env->make('admin.user.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                            </div>
                            <div class="card-footer">
                                <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-default"> Cancel </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.editor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.simple.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\feedback.loc\resources\views/admin/user/create.blade.php ENDPATH**/ ?>