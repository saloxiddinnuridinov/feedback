<div class="table-responsive">
    <table class="table" id="users-table">
        <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Surname</th>
            <th>Email</th>
            <th>Image</th>
            <th>Role</th>
            <th>Specialist</th>
            <th>Active</th>
            <th>Created at</th>
            <th colspan="3">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $i = 1;
        ?>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->surname); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><img src="<?php echo e(asset($user->image)); ?>" alt="User Image" style="max-width: 50px;"></td>
                <td><?php echo e($user->role); ?></td>
                <td><?php echo e($user->specialist); ?></td>
                <td>
                    <?php if($user->is_active): ?>
                        <i class="fa fa-check-circle text-success"></i>
                    <?php else: ?>
                        <i class="fa fa-times-circle text-danger"></i>
                    <?php endif; ?>
                </td>
                <td><?php echo e(\Carbon\Carbon::parse($user->created_at)->format('Y-m-d')); ?></td>
                <td width="120px">
                    <div style="display: block; margin-bottom: 5px;">
                        <a style="width: 100%" href="<?php echo e(route('users.show', $user->id)); ?>" class="btn btn-primary"><i class="fa fa-eye"></i></a>
                        <!-- View icon -->
                        <a style="width: 100%" href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-info"><i
                                class="fa fa-edit"></i></a>
                        <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" style="width: 100%;">
                                <i class="fa fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\OpenServer\domains\feedback.loc\resources\views/admin/user/table.blade.php ENDPATH**/ ?>