s

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 col-xl-12">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-header pb-0">
                                <h5>Edit Subject</h5>
                            </div>
                            <div class="card-body">
                                <form class="form theme-form" action="<?php echo e(route('users.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo method_field('put'); ?>
                                    <?php echo csrf_field(); ?>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="form-group col-sm-6">
                                                <?php echo Form::label('name', 'Name:'); ?>

                                                <?php echo Form::text('name', $user->name, ['class' => 'form-control', 'required']); ?>

                                            </div>

                                            <!-- Surname Field -->
                                            <div class="form-group col-sm-6">
                                                <?php echo Form::label('surname', 'Surname:'); ?>

                                                <?php echo Form::text('surname', $user->surname, ['class' => 'form-control', 'required']); ?>

                                            </div>

                                            <!-- Email Field -->
                                            <div class="form-group col-sm-6">
                                                <?php echo Form::label('email', 'Email:'); ?>

                                                <?php echo Form::text('email', $user->email, ['class' => 'form-control', 'required']); ?>

                                            </div>

                                            <!-- Password Field -->
                                            <div class="form-group col-sm-6">
                                                <label for="password">Password:</label>
                                                <input type="password" class="form-control" id="password" name="password">
                                            </div>

                                            <!-- Image Field -->
                                            <div class="form-group col-sm-6">
                                                <label for="image">Image:</label>
                                                <input type="file" class="form-control" id="image" name="image">
                                            </div>
                                            <div class="form-group col-sm-6">
                                                <img src="<?php echo e(asset($user->image)); ?>" alt="Post Image"
                                                     style="max-width: 100px; max-height: 100px;">
                                            </div>

                                            <!-- Role Field -->
                                            <div class="form-group col-sm-6">
                                                <?php echo Form::label('role', 'Role:'); ?>

                                                <?php echo Form::select('role', ['admin' => 'admin', 'user' => 'user'], $user->role, ['class' => 'form-control custom-select']); ?>

                                            </div>

                                            <!-- Role Field -->
                                            <div class="form-group col-sm-6">
                                                <?php echo Form::label('specialist', 'Specialist:'); ?>

                                                <?php echo Form::select('specialist', ['All' => 'All', 'Sirtqi' => 'Sirtqi', 'Masofaviy' => 'Masofaviy', 'Kunduzgi' => 'Kunduzgi'], $user->specialist, ['class' => 'form-control custom-select']); ?>

                                            </div>

                                            <!-- Is Active Field -->
                                            <div class="form-group col-sm-6">
                                                <?php echo Form::label('is_active', 'Active:'); ?>

                                                <div class="form-check">
                                                    <?php echo Form::hidden('is_active', 0, ['class' => 'form-check-input']); ?>

                                                    <?php echo Form::checkbox('is_active', 1, $user->is_active == 1, ['class' => 'form-check-input']); ?>

                                                    <?php echo Form::label('is_active', 'Is Active', ['class' => 'form-check-label']); ?>

                                                </div>
                                            </div>

                                            <?php
                                            $telegram_users = \App\Models\TelegramUser::all();
                                            ?>
                                            <div class="form-group col-sm-6">
                                                <?php echo Form::label('telegram_user', 'Telegram User:'); ?>

                                                <?php echo Form::select('telegram_user', $telegram_users->pluck('name', 'id')->toArray(), null, ['class' => 'form-control custom-select', 'placeholder' => 'Select a Telegram User']); ?>

                                            </div>


                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <div class="col-sm-9 offset-sm-3">
                                            <button class="btn btn-primary" type="submit">Submit</button>
                                            <a class="btn btn-secondary" href="<?php echo e(route('users.index')); ?>">Cancel</a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.editor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.simple.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\feedback.loc\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>