@extends('admin.layouts.simple.master')

@section('title', "\"Ipak yoʻli\" turizm va madiny meros xalqaro universiteti")

@section('style')

@endsection

@section('breadcrumb-title')

    <h3>Dashboard</h3>

@endsection

@section('breadcrumb-items')

@endsection

@section('content')

@endsection
@section('script')
@endsection
