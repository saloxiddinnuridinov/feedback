<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 footer-copyright text-center">
                <strong>Copyright &copy; 2024 <a href="https://univ-silkroad.uz/">"Ipak yoʻli" turizm va madiny meros xalqaro universiteti.</a></strong> Barcha huquqlar himoyalangan

            </div>
        </div>
    </div>
</footer>
